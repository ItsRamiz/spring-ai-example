package spring.ai.example.spring_ai_demo.service;

import jakarta.annotation.PostConstruct;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RagService {

    private final VectorStore vectorStore;
    private final ChatClient chatClient;
    private final ResourceLoader resourceLoader;


    public RagService(VectorStore vectorStore, ChatClient.Builder chatClientBuilder, ResourceLoader resourceLoader) {
        this.vectorStore = vectorStore;
        this.chatClient = chatClientBuilder.build();
        this.resourceLoader = resourceLoader;
    }

    @PostConstruct
    public void loadData() throws IOException {
        System.out.println("Starting RAG ingestion...");

        System.out.println("Starting RAG ingestion from TXT file...");

        Resource resource = resourceLoader.getResource("classpath:data/ramiz-info.txt");

        String text = resource.getContentAsString(StandardCharsets.UTF_8);

        List<Document> documents = List.of(text.split("\\."))
                .stream()
                .map(String::trim)
                .filter(chunk -> !chunk.isEmpty())
                .map(Document::new)
                .toList();

        vectorStore.add(documents);

        System.out.println("Stored chunks: " + documents.size());
    }

    public String ask(String question) {

        List<Document> documents = vectorStore.similaritySearch(
                SearchRequest.builder()
                        .query(question)
                        .topK(3)
                        .build()
        );

        String context = documents.stream()
                .map(Document::getText)
                .collect(Collectors.joining("\n"));

        System.out.println("Question: " + question);
        System.out.println("Retrieved context:\n" + context);

        return chatClient.prompt()
                .user("""
                        Answer the question using only the context below.

                        Context:
                        %s

                        Question:
                        %s
                        """.formatted(context, question))
                .call()
                .content();
    }
}