package spring.ai.example.spring_ai_demo.service;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;
import spring.ai.example.spring_ai_demo.tools.WeatherTool;

@Service
public class AiService {

    private final ChatClient chatClient;
    private final WeatherTool weatherTool;

    public AiService(ChatClient chatClient, WeatherTool weatherTool) {
        this.chatClient = chatClient;
        this.weatherTool = weatherTool;
    }


    public String ask(String userInput) {

        String systemPrompt = """
                You are a helpful assistant.

                If the user asks about weather, you must use the weather tool.
                Do not invent weather information.
                Do not answer weather questions from your own knowledge.
                Use the tool result as the source of truth.
                """;

        return chatClient
                .prompt()
                .system(systemPrompt)
                .user(userInput)
                .tools(weatherTool)
                .call()
                .content();
    }
}