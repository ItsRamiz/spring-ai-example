package spring.ai.example.spring_ai_demo.tools;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class WeatherTool {

    private final RestClient restClient;

    public WeatherTool() {
        this.restClient = RestClient.builder()
                .baseUrl("https://wttr.in")
                .build();
    }

    @Tool(description = "Get the current real weather for a city")
    public String getWeather(
            @ToolParam(description = "City name, for example: Tel Aviv, London, Paris")
            String city)

    {
        System.out.println("Weather tool was called for city: " + city);

        String weather = restClient.get()
                .uri("/{city}?format=Weather in %l: temperature %t, condition %C, humidity %h", city)
                .retrieve()
                .body(String.class);

        if (weather == null || weather.isBlank()) {
            return "No weather data found for " + city;
        }

        return weather;
    }
}